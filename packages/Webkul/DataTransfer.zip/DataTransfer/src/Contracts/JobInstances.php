<?php

namespace Webkul\DataTransfer\Contracts;

interface JobInstances {}
