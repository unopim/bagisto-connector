<?php

namespace Webkul\DataTransfer\Contracts;

interface JobTrackBatch {}
