<?php

namespace Webkul\DataTransfer\Contracts;

interface JobTrack {}
