<?php

namespace Webkul\DataTransfer\Models;

use Konekt\Concord\Proxies\ModelProxy;

class JobTrackBatchProxy extends ModelProxy {}
