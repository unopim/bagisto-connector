<?php

namespace Webkul\DataTransfer\Models;

use Konekt\Concord\Proxies\ModelProxy;

class JobTrackProxy extends ModelProxy {}
