<?php

namespace Webkul\Admin\Tests;

use Tests\TestCase;
use Webkul\User\Tests\Concerns\UserAssertions;

class AdminTestCase extends TestCase
{
    use UserAssertions;
}
