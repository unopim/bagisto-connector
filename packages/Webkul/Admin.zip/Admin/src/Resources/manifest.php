<?php

return [
    'name'    => 'Webkul UnoPim Admin',
    'version' => core()->version(),
];
