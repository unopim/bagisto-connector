<table {{ $attributes->merge(['class' => 'w-full text-sm text-left min-w-[800px]']) }}>
    {{ $slot }}
</table>

