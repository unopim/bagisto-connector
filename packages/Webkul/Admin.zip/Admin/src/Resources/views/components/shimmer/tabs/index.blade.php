<div class="flex gap-4 justify-left pt-2 bg-neutral-100 max-sm:hidden">
    <span class="shimmer block w-[141px] h-10 bg-gray-300"></span>

    <span class="shimmer block w-[70px] h-10 bg-gray-300"></span>

    <span class="shimmer block w-[101px] h-10 bg-gray-300"></span>

    <span class="shimmer block w-52 h-10 bg-gray-300"></span>
</div>