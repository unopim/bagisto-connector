<?php

namespace Webkul\Admin\Helpers\Reporting;

abstract class AbstractReporting {}
